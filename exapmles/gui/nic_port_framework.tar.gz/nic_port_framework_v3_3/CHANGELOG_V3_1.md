# V3.1 change summary

V3.1 is an additive hardening iteration over V3.

## Integrated from traditional source scanners / API registries

- Exact Linux API symbol catalogue, externally configurable and extensible.
- Regex API-family coverage retained as a secondary signal.
- Per-function API-hit inventory with detection provenance.
- Per-function weighted portability/risk triage and recommendation.
- Linux-specific functionality-family report.
- Include classification report.
- Project-wide Linux API usage report.
- Human portability summary rendered from an external template.
- API-catalogue gap report for iterative catalogue growth.

## Further externalization

Moved project/domain/policy data out of Python:

- Linux API exact catalogue and family patterns.
- Linux-specific feature patterns.
- FreeBSD target hints/subsystem patterns/risk weights/ignore rules.
- Portability scoring and thresholds.
- include classification.
- Kbuild/GCC -> Clang normalization lists.
- report layouts.
- context limits.
- stage/confidence/authority/risk model.
- result schemas.
- output-manifest catalogue.
- all operational prompt/record/report templates.

Transient algorithmic data structures and parser syntax implementation remain code by design.

## Single-entrypoint improvements

- `nic_port_pipeline.py --manifest ...` is the canonical operational entrypoint.
- optional manifest-defined bootstrap steps can build tools/source and create the compile DB using explicit argv execution with `shell=False`.
- `<output.root>/output_manifest.json` remains the canonical exitpoint and recursively indexes produced directories.

## Iterative/non-regression behavior

- semantic/catalog/scoring changes are fingerprinted separately from policy/templates/report/output navigation.
- exact catalogue conflicts fail by default rather than silently overriding.
- derived scores are triage signals only; FAR/file/subsystem/final decisions remain evidence-backed engineering decisions.
- catalogue gaps are reported but never auto-promoted.
