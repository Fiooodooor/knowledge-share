# V3.3 changelog

- Added resumable per-TU semantic cache with gzip storage.
- Added cache identity from source hash, normalized compile command, dependency snapshot, extractor hash and semantic PP configuration.
- Added `resume` pipeline command that deliberately skips bootstrap.
- Added `manifest/extraction_checkpoint.json` with atomic per-TU progress updates.
- Added `manifest/preflight.json` and `manifest/artifact_budget.json`.
- Added configurable pre-TU memory/resource guard and raw artifact size budgets.
- Made global duplicate resolution deterministic under parallel LibTooling jobs.
- Made successful AST fallback recovery cacheable.
- Kept cache/checkpoint/runtime metrics outside the semantic baseline fingerprint.
- Extended `diagnose-extraction` with checkpoint/cache/preflight/artifact-budget information.
- Added `configuration.extraction_runtime` to the canonical manifest loader/default profile/schema.
- Curated extraction health/cache/checkpoint artifacts in the output-manifest catalogue.
- Updated stable entrypoints to V3.3 implementations.
- Updated full IDPF bootstrap example to compile the stable `nic_port_clang_extractor.cpp` entrypoint.
- Added local-source vs included-header function counts and a default local-function quality gate.
