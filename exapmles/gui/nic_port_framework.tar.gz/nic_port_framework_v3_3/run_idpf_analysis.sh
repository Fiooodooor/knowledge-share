#!/usr/bin/env bash
set -euo pipefail

export DEBUG=true

echo "Stage 0. Start: Pre-execution"
[ "$DEBUG" == 'true' ] && set -x && \
SCRIPT_DIR="$(readlink -f "$(dirname -- "${BASH_SOURCE[0]}")")" && \
MANIFEST="${1:-${SCRIPT_DIR}/examples/idpf.full.manifest.json}" && \
PIPELINE="${SCRIPT_DIR}/nic_port_pipeline.py" && \
export KERNEL_BUILD=/usr/src/linux-headers-6.1.0-52-amd64 && \
export FRAMEWORK_DIR="/opt/nic_port_orchestrator/nic_port_framework" && \
export FRAMEWORK_OUT_DIR="${FRAMEWORK_DIR}/../out" && \
export FRAMEWORK_REPO_DIR="/opt/porting/ethernet-linux-idpf" && \
export FRAMEWORK_REPO_SRC_DIR="${FRAMEWORK_REPO_DIR}/idpf/src"
FRAMEWORK_STAGE_0_RESULT="$?"
echo "Stage 0. End: $FRAMEWORK_STAGE_0_RESULT"

python3 "${PIPELINE}" --manifest "$MANIFEST" validate-manifest
set +e
python3 "${PIPELINE}" --manifest "$MANIFEST" prepare
rc=$?
set -e
if [ "${rc}" -ne 0 ]; then
  python3 "${PIPELINE}" --manifest "$MANIFEST" diagnose-extraction || true
  echo "Preparation failed. Fix the reported TU/environment issue and run:" >&2
  echo "  python3 "${PIPELINE}" --manifest '$MANIFEST' resume" >&2
  [ "$DEBUG" == 'true' ] && set +x
  exit "${rc}"
fi
python3 "${PIPELINE}" --manifest "$MANIFEST" diagnose-extraction
python3 "${PIPELINE}" --manifest "$MANIFEST" status --verbose
[ "$DEBUG" == 'true' ] && set +x
