# NIC Port Framework V3.2 — extraction resilience and transactional workspace validity

V3.2 is an additive hardening iteration driven by the first real IDPF V3.1 run. It preserves the V3.1 manifest/configuration model and orchestration contracts while changing the *runtime shape* of source extraction so a large kernel driver cannot silently leave a half-current workspace.

## Why this iteration exists

The IDPF run successfully parsed nine translation units, then seven later units produced zero semantic records and the automatic AST-JSON fallback did not complete. The same workspace contained a roughly 416 MB merged LibTooling JSON plus per-TU shards around 40–49 MB. This exposed memory amplification and insufficient extraction-state observability.

## Main changes

- LibTooling results are normalized one TU at a time. Raw JSON documents are released immediately.
- Repeated project-header function/struct/enum records are de-duplicated as TUs arrive, matching the previous resolver's first-occurrence semantics while reducing parent-process memory.
- Preprocessor events are filtered in the LibTooling extractor before serialization. Default scope is the configured project source root, with an external event-kind allow-list.
- Successful LibTooling raw shards are deleted by default. Failed shards are retained for diagnosis. The giant merged `raw_extractor/libtooling.json` is disabled by default.
- Per-TU diagnostics now record failure class, return code/signal, stderr/stdout tails, counts, PP filtering statistics, raw-shard provenance and best-effort memory telemetry.
- SIGKILL (`returncode == -9`) is classified as `out_of_memory_suspected`.
- `auto` fallback is failure-class aware. It does not answer a signal/OOM/timeout/frontend failure by immediately launching a much heavier full AST dump.
- AST fallback is sequential by default, limited in count, and spools JSON stdout to a temporary file rather than capturing it as one giant Python string.
- `manifest/run_state.json` and `manifest/extraction_quality.json` define transactional workspace validity. Orchestration requires current state `COMPLETE` and quality `PASS`.
- Failed extraction writes an exit manifest and diagnostics but deliberately does not present a canonical KB as current.
- Added `nic_port_pipeline.py ... diagnose-extraction` for current-run diagnosis without entering orchestration.
- Orchestration baseline fingerprinting now separates raw run provenance from stable semantic provenance, so timing/elapsed telemetry does not stale all accepted analysis on an otherwise identical rerun.
- Output-manifest know-how/significant-file entries include the new state, quality, diagnostic and raw-index artifacts.

## New configuration

`config/rules/extraction_runtime.json` controls:

- diagnostics/tails/memory telemetry;
- LibTooling timeout, PP scope/event kinds and raw retention;
- AST fallback eligibility/jobs/limits;
- extraction quality gates;
- workspace diagnostic artifact paths.

It is referenced by the default manifest profile and fingerprinted separately as semantic, quality and operational configuration.

## Compatibility

V3/V3.1 entrypoint files remain as wrappers. New deployments should use the stable entrypoint names:

```text
nic_port_pipeline.py
nic_port_context_builder.py
nic_port_orchestrator.py
nic_port_clang_extractor.cpp
```

The stable wrappers currently target V3.2.
